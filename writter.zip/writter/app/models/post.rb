class Post < ApplicationRecord
  belongs_to :user
  has_many :post_tags
  has_many :tags, through: :post_tags
  
  has_many :post_hashtags
  has_many :hashtags, through: :post_hashtags
  
  has_many :comments, dependent: :destroy
  has_many :likes, dependent: :destroy
  has_many :likers, through: :likes, source: :user
  has_many_attached :images
  
  validates :content, presence: true

  private
  # Finds and tags users mentioned in the post content
  def tag_users
    usernames = content.scan(/@(\w+)/).flatten
    usernames.each do |username|
      user = User.find_by(username: username)
      # Handle the case where the user is found and notify/tag them
    end
  end

  # Searches posts by hashtag
  def self.search_by_hashtag(hashtag)
    joins(:tags).where(tags: { name: hashtag })
  end
end
