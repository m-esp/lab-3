class PagesController < ApplicationController
  def home
  end

  def about
  end

  def contact
  end
end
