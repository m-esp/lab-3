class SessionsController < ApplicationController
    def guest_login
      # Find or create a guest user
      guest_user = User.find_or_create_by(email: 'guest@example.com') do |user|
        user.password = 'guestpassword'
        user.password_confirmation = 'guestpassword'
      end
  
      # Sign in the guest user
      sign_in guest_user
      redirect_to root_path, notice: 'Logged in as guest.'
    end
  end
  