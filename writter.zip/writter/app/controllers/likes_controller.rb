class LikesController < ApplicationController
  before_action :set_post

  def create
    if @post.likes.where(user: current_user).exists?
      flash[:notice] = "You've already liked this post."
    else
      @post.likes.create(user: current_user)
    end
    redirect_to @post
  end

  def destroy
    like = @post.likes.find(params[:id])
    if like.user == current_user
      like.destroy
    end
    redirect_to @post
  end

  private

  def set_post
    @post = Post.find(params[:post_id])
  end
end
