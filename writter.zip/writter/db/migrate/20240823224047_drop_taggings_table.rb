class DropTaggingsTable < ActiveRecord::Migration[6.0]
  def up
    drop_table :taggings
  end

  def down
    create_table :taggings do |t|
      t.references :post, null: false, foreign_key: true
      t.references :tag, null: false, foreign_key: true
      t.timestamps
    end
  end
end
